# formacaoEM-3tri
##Repositório para guardar o projeto feito na formação Ensino Médio
!![image](https://github.com/cidaci2000/Forma-oteceirotrimestre/blob/main/Sem%20t%C3%ADtulo.png)
